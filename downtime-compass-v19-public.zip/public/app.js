const $=(id)=>document.getElementById(id);
const ITEMS=Object.entries(CATALOG).flatMap(([part,s])=>s.split(";").map(r=>{const [name,alias,group,x]=r.split("|");return{name,alias,group,part,noPhoto:x==="x"}}));
const byName=(n)=>ITEMS.find(i=>i.name===n);
// 鼻フルコースの公開料金表10プラン（万円、確認日 2026-11-03）
const PLANS=[77,80,110,110,132,138.6,160,165,165,198];
const FLAGS=[["圧迫しても止まらない出血"],["短時間で急に広がる腫れ、片側だけの急な腫れ"],["強くなる痛み（痛み止めが効かない、一度良くなってから悪化した）"],["38度以上の発熱"],["赤みや熱感の広がり、膿、悪臭のある分泌物"],["皮膚の色の変化（白っぽい、紫、黒ずみ）と強い痛み"],["傷が開いた、入れたものが透けて見える・出てきた"],["目の周りの腫れ、見え方の変化"],["息苦しさ、胸の痛み、意識がもうろうとする",true]];
const PRESSURE=["今日契約すれば割引と言われた","勧められて施術が増えた","総額の内訳をもらっていない","リスクと合併症の説明を受けていない","修正や保証の条件を確認していない"];
const BANDS={days:[3,7,14,30,90,180,365],fast:[100,70,45,20,8,2.5,1],std:[100,85,65,33,15,5,2.5],slow:[100,95,80,55,30,12,5]};
const LEVELS=[["pain","痛み"],["swell","腫れの感じ"],["bruise","内出血"]];
const SAMPLE=[[1,3,4,2],[2,3,5,3],[3,2,5,4],[4,2,4,4],[5,2,4,3],[6,1,3,3],[7,1,3,2]];
// AI生成の架空の人物による、鼻の手術のモデル経過（相方が生成）。実在の症例ではない。
const MODEL=[["day0","当日",0],["day3","3日後",3],["week1","1週間後",7],["month1","1か月後",30],["month3","3か月後",90],["month6","半年後",180],["year1","1年後",365]];

// 公開価格の幅（万円）。相方の試作ZIPのデータから、施術の範囲がはっきり対応するものだけ。支払額の統計ではない。
const SITE="美容医療の情報サイト",CLINIC="クリニックの公開料金例";
const S={misao:[SITE,"https://media.misao-ladies.jp/biyou-iryou-hiyou-souba/"],cj:[SITE,"https://www.clinicjapan.net/plastic-surgery-japan/"],cj26:[SITE,"https://www.clinicjapan.net/japan-cosmetic-surgery-price-list-2026/"],cjhow:[SITE,"https://www.clinicjapan.net/how-much-plastic-surgery-japan/"],sbcPtosis:[CLINIC,"https://www.s-b-c.net/eyelid/sekkai/gankenkasui/"],sbcTare:[CLINIC,"https://www.s-b-c.net/eyelid/sekkai/tareme/"],verite:[CLINIC,"https://www.veriteclinic.or.jp/progress/eyes/ptosis/"],keisei:[CLINIC,"https://www.keisei-cs.com/medical-treatment/drooping-eye.html"],mizuno:[CLINIC,"https://www.mizunomori.com/diagnosis/eye/tareme/"]};
const REF_PRICE={
  "鼻フルコース":[77,198,[["ジョウクリニック「鼻フルコース」オープン法132万円／クローズ法165万円",""],["キハルクリニック ノーマル77万円／フルコース110万円／肋軟骨フルコース165万円",""],["V CLINIC スタンダード80万円／プレミアム110万円／プラチナ160万円",""],["BIANCA Clinic「鼻フルSET」138.6万円",""],["THE ROPPONGI CLINIC「鼻フルコース」198万円",""]].map(([t,u])=>[CLINIC+"："+t+"（公式料金表、確認日 2026-11-03。プランごとに含まれる施術は異なります）",u])],
  "重瞼術（埋没法）":[3,20,[S.misao]],"重瞼術（切開法）":[20,40,[S.cj]],"目頭切開":[15,35,[S.misao]],"目尻切開":[15,35,[S.misao]],
  "眼瞼下垂手術":[22.8,55,[S.sbcPtosis,S.verite,S.keisei]],"下眼瞼下制術":[20,55,[S.sbcTare,S.mizuno,S.keisei]],"上まぶたの脂肪取り":[7.6,16.2,[S.sbcPtosis]],
  "鼻尖縮小術":[15,80,[S.cj26,S.cj]],"鼻尖形成術":[15,80,[S.cj26,S.cj]],"鼻中隔延長術":[80,200,[S.cj]],"隆鼻術（プロテーゼ）":[30,80,[S.cj]],"小鼻縮小術":[15,80,[S.cj26,S.cj]],
  "オトガイ形成":[20,50,[S.cj]],"口唇ヒアルロン酸":[3,10,[S.misao]],"下顎骨骨切り・削り":[80,200,[S.cj]],"頬骨骨切り・削り":[80,200,[S.cj]],
  "バッカルファット除去":[15,40,[S.cj,S.misao]],"スレッドリフト":[10,35,[S.cjhow,S.misao]]
};

const store={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}},del(k){try{localStorage.removeItem(k)}catch{}}};
const toISO=d=>new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10);
const daysAgo=n=>toISO(new Date(Date.now()-n*864e5));
const diff=(a,b)=>Math.round((new Date(b)-new Date(a))/864e5);
const today=daysAgo(0);
const md=iso=>iso?`${Number(iso.slice(5,7))}/${Number(iso.slice(8,10))}`:"−";
const num=v=>Math.round(v*10)/10;
const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e};
const link=(text,href)=>{const a=el("a","",text);a.href=href;a.target="_blank";a.rel="noopener";return a};
const checked=(n)=>[...document.querySelectorAll(`input[name=${n}]:checked`)].map(e=>Number(e.value));
const list=(id,arr,name)=>$(id).insertAdjacentHTML("beforeend",arr.map((x,i)=>`<label class="check"><input type="checkbox" name="${name}" value="${i}"><span>${Array.isArray(x)?x[0]:x}</span></label>`).join(""));
list("pressure",PRESSURE,"pressure");list("flags",FLAGS,"flag");
$("flag-ref").replaceChildren(...FLAGS.map(f=>el("li","",f[0])));

// 画面の切り替え
const PANELS={home:"home",price:"price",estimate:"estimate-tab",after:"after"};
function showTab(name){for(const [t,id] of Object.entries(PANELS)){$("tab-"+t).setAttribute("aria-selected",String(t===name));$(id).hidden=t!==name}scrollTo(0,0)}
for(const t of Object.keys(PANELS))$("tab-"+t).onclick=()=>showTab(t);
for(const b of document.querySelectorAll("[data-go]"))b.onclick=()=>showTab(b.dataset.go);

// 施術の選択：受けた施術（after）と、気になる施術（before）を別々に持つ
(()=>{const old=store.get("procs",null);if(Array.isArray(old)){if(store.get("procsAfter",null)===null)store.set("procsAfter",old);if(store.get("procsBefore",null)===null)store.set("procsBefore",old);store.del("procs")}})();
const KEY={after:"procsAfter",before:"procsBefore"};
const sel={after:store.get(KEY.after,[]).filter(byName),before:store.get(KEY.before,[]).filter(byName)};
let pickFor="before",part="";
const MAX=5;
const groupsOf=(names)=>[...new Set(names.map(n=>byName(n).group))].map(g=>GROUPS[g]);
const afterGroups=()=>groupsOf(sel.after);
function setSel(which,names){sel[which]=names;store.set(KEY[which],names);refresh()}
function renderParts(){
  const box=$("parts");box.replaceChildren();
  for(const p of Object.keys(CATALOG)){const b=el("button","",p);b.type="button";b.setAttribute("aria-pressed",String(p===part));b.onclick=()=>{part=p===part?"":p;$("q").value="";renderParts();renderResults()};box.append(b)}
}
function renderResults(){
  const q=$("q").value.trim(),cur=sel[pickFor];
  const hits=ITEMS.filter(i=>q?(i.name+i.alias+i.part).includes(q):i.part===(part||"鼻")).slice(0,40);
  const box=$("results");box.replaceChildren();
  if(!hits.length){box.append(el("p","muted","見つかりません。別の呼び方でも試してください。"));return}
  for(const it of hits){
    const on=cur.includes(it.name),b=el("button");b.type="button";b.setAttribute("aria-pressed",String(on));
    const n=el("span","",it.name);if(it.alias)n.append(el("small","",it.alias));
    b.append(n,el("span","tag",on?"✓ 選択中":pickFor==="before"&&REF_PRICE[it.name]?"価格あり":""));
    b.onclick=()=>{if(on)setSel(pickFor,cur.filter(x=>x!==it.name));else if(cur.length<MAX)setSel(pickFor,[...cur,it.name]);renderResults()};
    box.append(b);
  }
}
for(const b of document.querySelectorAll("[data-pick]"))b.onclick=()=>{pickFor=b.dataset.pick;const cur=sel[pickFor];part=cur.length?byName(cur[0]).part:"鼻";$("q").value="";$("picker-title").textContent=pickFor==="after"?"受けた施術を選ぶ":"気になる施術を選ぶ";document.querySelector(".has-price-key").hidden=pickFor!=="before";renderParts();renderResults();$("picker").showModal()};
$("picker-done").onclick=()=>$("picker").close();
$("q").oninput=renderResults;
function renderChips(){
  for(const box of document.querySelectorAll("[data-chips]")){
    const which=box.dataset.chips;box.replaceChildren();
    if(!sel[which].length)box.append(el("p","fine","まだ選ばれていません。"));
    for(const n of sel[which]){const c=el("button","chip");c.type="button";c.append(el("span","",n),el("span","x","×"));c.setAttribute("aria-label",n+"を外す");c.onclick=()=>setSel(which,sel[which].filter(x=>x!==n));box.append(c)}
  }
}

// 出典：1行に畳む
const CHECKED="2026-11-06";
const srcKind=(g)=>!g.src?"":g.src[1].includes("minds")?"診療指針":g.src[1].includes("kobe")?"大学病院":g.src[1].includes("jsprs")?"学会":"公的機関";
function srcFold(kind,items){
  const d=el("details","src"),s=el("summary");s.append(el("span","","出典："+kind));d.append(s);
  const ul=el("ul");for(const [t,u,date] of items){const li=el("li");li.append(u?link(t,u):el("span","",t));if(date)li.append(el("span","src-date","確認 "+date));ul.append(li)}
  d.append(ul);return d;
}
const srcLine=(g)=>g.src?srcFold(srcKind(g),[[g.src[0],g.src[1],CHECKED]]):el("span");

// 1 価格：施術ごとに、公開価格の幅を「安め・中くらい・高め」の3つの枠で見せる。
// 枠は幅を同じ間隔で分けた位置（件数の多さではない）。鼻フルだけは公開料金表10プランの件数を枠ごとに出す。
const quantile=(a,q)=>{const p=(a.length-1)*q,l=Math.floor(p);return a[l]+(a[Math.ceil(p)]-a[l])*(p-l)};
const priced=()=>sel.before.filter(n=>REF_PRICE[n]);
const sumRange=()=>{const p=priced();return p.length?[num(p.reduce((s,n)=>s+REF_PRICE[n][0],0)),num(p.reduce((s,n)=>s+REF_PRICE[n][1],0))]:null};
const TIER=["安め","中くらい","高め"];
const fmt=(v,span)=>String(span>=30?Math.round(v):num(v));
function thirds(lo,hi){const st=(hi-lo)/3;return[[lo,lo+st],[lo+st,lo+2*st],[lo+2*st,hi]]}
const tierOf=(v,lo,hi)=>v<lo?-1:v>hi?3:Math.min(2,Math.floor((v-lo)/((hi-lo)/3||1)));
function rangeChart(mark,markLabel){
  const rows=priced().map(n=>({name:n,lo:REF_PRICE[n][0],hi:REF_PRICE[n][1],plans:n==="鼻フルコース"?PLANS:null}));
  const sr=sumRange();if(rows.length>1)rows.push({name:"合計の目安",lo:sr[0],hi:sr[1],sum:true});
  const target=rows.at(-1);
  const out=el("div","stack tiers");
  for(const r of rows){
    const row=el("div","tier-row"+(r.sum?" sum":"")),head=el("div","tier-head");
    head.append(el("b","",r.name),el("span","",`${r.lo}〜${r.hi}万円`));row.append(head);
    const strip=el("div","tier-strip"),span=r.hi-r.lo,mt=mark&&r===target?tierOf(mark,r.lo,r.hi):null;
    thirds(r.lo,r.hi).forEach(([a,b],i)=>{
      const c=el("div","tier t"+i+(mt===i?" hit":""));
      c.append(el("b","",TIER[i]),el("span","",`${fmt(a,span)}〜${fmt(b,span)}`));
      if(r.plans){const n=r.plans.filter(p=>i===2?p>=a&&p<=b:p>=a&&p<b).length;c.append(el("small","",`${n}件`))}
      if(mt===i)c.append(el("em","",`${markLabel} ${mark}`));
      strip.append(c);
    });
    row.append(strip);
    if(mt===-1||mt===3)row.append(el("p","tier-out",`${markLabel} ${mark}万円は、この幅より${mt<0?"下":"上"}です。`));
    out.append(row);
  }
  out.append(el("p","fine","3つの枠は、公開されている価格の幅を同じ間隔で分けた位置です。どの枠に多いかは示していません。"+(rows.some(r=>r.plans)?"鼻フルコースの「◯件」は、公開料金表10プランのうち、その枠に入る数です。":"")));
  return out;
}
function positionText(total){
  const rows=priced();if(!rows.length)return"";
  const [lo,hi]=rows.length>1?sumRange():REF_PRICE[rows[0]].slice(0,2),t=tierOf(total,lo,hi);
  const base=t<0?`公開されている幅（${lo}〜${hi}万円）より下です。含まれる施術の範囲を確認しましょう。`:t>2?`公開されている幅（${lo}〜${hi}万円）より上です。追加された項目と、その理由を確認しましょう。`:`公開されている幅の「${TIER[t]}」の枠にあります。`;
  return base+"高い・安いの良し悪しは判定しません。";
}
function renderPrice(){
  const has=sel.before.length>0;$("price-box").hidden=!has;$("ask-box").hidden=!has;if(!has)return;
  const box=$("range-chart");box.replaceChildren();
  const missing=sel.before.filter(n=>!REF_PRICE[n]);
  const budget=Number($("budget").value)||null;
  if(priced().length)box.append(rangeChart(budget,"予算"));
  if(missing.length)box.append(el("p","note-info",`${missing.join("、")}は、公開価格のデータをまだ集めていません。`));
  const sr=sumRange();
  $("range-sum").hidden=priced().length<2;if(sr)$("range-sum").textContent="合計は、それぞれの幅を足しただけです。セット料金や割引、麻酔・薬代は入っていません。";
  $("budget-text").hidden=true;
  const srcs=priced().flatMap(n=>REF_PRICE[n][2]);const uniq=[...new Map(srcs.map(s=>[s[1]||s[0],s])).values()];
  $("range-src").replaceChildren(uniq.length?srcFold([...new Set(uniq.map(s=>s[0].startsWith(CLINIC)?CLINIC:s[0]))].join("・")+`（${uniq.length}件）`,uniq.map(([k,u])=>u?[new URL(u).hostname.replace(/^www\./,"")+"（"+k+"）",u]:[k,""])):el("span"));
  const asks=[...new Set(groupsOf(sel.before).flatMap(g=>g.ask))].slice(0,6);
  $("ask-list").replaceChildren(...asks.map(t=>el("li","",t)));
}
$("budget").oninput=renderPrice;
$("copy-ask").onclick=async()=>{const t=[...$("ask-list").children].map((li,i)=>`${i+1}. ${li.textContent}`).join("\n");try{await navigator.clipboard.writeText(t);$("copy-ask").textContent="✓ コピーしました"}catch{$("copy-ask").textContent="コピーできませんでした"}setTimeout(()=>{$("copy-ask").textContent="メモにコピー"},2400)};

// 2 見積書
function priceCompare(total,box){
  box.replaceChildren();if(!total)return;
  if(!priced().length){box.append(el("p","fine","比べる施術を「1 価格」で選ぶと、公開されている価格の幅と比べられます。"));return}
  box.append(el("h3","","公開されている価格と比べる"),rangeChart(total,"見積もり"),el("p","",positionText(total)));
}
$("total").oninput=()=>priceCompare(Number($("total").value)||null,$("total-out"));
function renderKnow(){
  const box=$("know");box.replaceChildren();
  if(!sel.before.length){box.append(el("p","fine","「1 価格」で施術を選ぶと、ここに出ます。"));return}
  sel.before.forEach((n,i)=>{
    const g=GROUPS[byName(n).group],det=el("details","know");det.open=i===0;det.append(el("summary","",n));
    const b=el("div","stack");
    if(g.guide)b.append(el("p","note-info","指針の記載："+g.guide));
    if(g.know.length){const ul=el("ul","dots");for(const t of g.know)ul.append(el("li","",t));b.append(el("h3","","知っておくこと"),ul)}
    if(g.flow.length){const ul=el("ul","dots");for(const [lab,t] of flowRows(g))ul.append(el("li","",lab+"："+t));b.append(el("h3","","ダウンタイムの目安"),ul)}
    b.append(srcLine(g));det.append(b);box.append(det);
  });
}
let estFile=null;
$("estimate").onchange=e=>{const label=e.target.parentElement,f=e.target.files[0];estFile=f||null;label.querySelector("img")?.remove();label.querySelector("span").hidden=!!f;if(f){const img=new Image();img.alt="";img.src=URL.createObjectURL(f);label.prepend(img)}};
const yen=n=>n?`${(n/10000).toLocaleString("ja-JP")}万円`:"読み取れず";
let est={items:[],total:null};
function showEstimate(r){
  if(!r.isEstimate){$("est-status").textContent="見積書として読み取れませんでした。別の画像で試してください。";return}
  est={items:r.items.map(i=>({name:i.name,man:i.amountYen?i.amountYen/10000:null})),total:r.totalYen?r.totalYen/10000:null};
  renderEstItems();
  $("est-missing").replaceChildren(...r.notFound.map(t=>el("li","",t)));$("est-missing-box").hidden=!r.notFound.length;
  $("est-questions").value=r.questions.map((q,i)=>`${i+1}. ${q}`).join("\n");
  if(r.doctorName)$("doctor").value=r.doctorName;
  $("est-out").hidden=false;$("est-status").textContent="";$("est-out").scrollIntoView({behavior:"smooth",block:"start"});
}
// 読み取り結果は直せる。直した金額で比べる。
function renderEstItems(){
  const box=$("est-items");box.replaceChildren();
  est.items.forEach((it,k)=>{
    const li=el("li","edit"),n=el("input"),m=el("input"),x=el("button","del","×");
    n.type="text";n.value=it.name;n.setAttribute("aria-label",`項目${k+1}の名前`);n.oninput=()=>{it.name=n.value};
    m.type="number";m.inputMode="decimal";m.step="0.1";m.min="0";m.value=it.man??"";m.placeholder="読み取れず";m.setAttribute("aria-label",`項目${k+1}の金額（万円）`);m.oninput=()=>{it.man=m.value===""?null:Number(m.value);estCheck()};
    x.type="button";x.setAttribute("aria-label",`項目${k+1}を消す`);x.onclick=()=>{est.items.splice(k,1);renderEstItems()};
    const w=el("span","yen");w.append(m,el("small","","万円"));li.append(n,w,x);box.append(li);
  });
  const add=el("li","add"),ab=el("button","text-btn","＋ 項目を足す");ab.type="button";ab.onclick=()=>{est.items.push({name:"",man:null});renderEstItems()};add.append(ab);box.append(add);
  const tl=el("li","edit sum"),tn=el("b","","総額"),tm=el("input");tm.type="number";tm.inputMode="decimal";tm.step="0.1";tm.min="0";tm.value=est.total??"";tm.placeholder="読み取れず";tm.setAttribute("aria-label","総額（万円）");
  tm.oninput=()=>{est.total=tm.value===""?null:Number(tm.value);estCheck()};
  const tw=el("span","yen");tw.append(tm,el("small","","万円"));tl.append(tn,tw,el("span"));box.append(tl);
  estCheck();
}
function estCheck(){
  const sum=num(est.items.reduce((s,i)=>s+(i.man||0),0)),box=$("est-check");
  const miss=est.items.some(i=>i.man==null);
  box.hidden=false;
  box.className=est.total==null?"note-warn":miss||Math.abs(sum-est.total)>0.05?"note-warn":"done";
  box.textContent=est.total==null?"総額を読み取れませんでした。見積書を見て、総額を入れてください。":miss?"金額を読み取れなかった項目があります。見積書を見て入れてください。":Math.abs(sum-est.total)>0.05?`内訳の合計（${sum}万円）と総額（${est.total}万円）が合いません。値引き、税、読み間違いがないか、見積書と見比べてください。`:"内訳の合計と総額が合っています。";
  priceCompare(est.total,$("est-price"));
}
function working(id,steps){const box=$(id);let i=0;box.className="working";box.textContent=steps[0];const t=setInterval(()=>{i=Math.min(i+1,steps.length-1);box.textContent=steps[i]},2600);return()=>{clearInterval(t);box.className="fine"}}
const errorText=e=>e?.message||"作成できませんでした。もう一度試してください。";
async function post(url,body){const res=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||"作成できませんでした。もう一度試してください。");return data}
function toJpeg(file){return new Promise((ok,ng)=>{const url=URL.createObjectURL(file),img=new Image();img.onerror=()=>ng(new Error("この写真は読み込めません。JPEGかPNGで試してください。"));img.onload=()=>{const k=Math.min(1,1024/Math.max(img.naturalWidth,img.naturalHeight)),c=document.createElement("canvas");c.width=Math.round(img.naturalWidth*k);c.height=Math.round(img.naturalHeight*k);c.getContext("2d").drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);ok(c.toDataURL("image/jpeg",.85).split(",")[1])};img.src=url})}
async function runEstimate(blob){
  const btn=$("est-run");btn.disabled=true;const stop=working("est-status",["Geminiが見積書を読んでいます","項目と金額を整理しています","確認できていないことを探しています"]);$("est-out").hidden=true;
  try{const r=await post("/api/estimate",{image:await toJpeg(blob),consent:true});stop();showEstimate(r)}
  catch(e){stop();$("est-status").textContent=errorText(e)}finally{btn.disabled=false}
}
$("est-run").onclick=()=>{
  if(!estFile){$("est-status").textContent="見積書の写真を選んでください。";return}
  if(!$("est-consent").checked){$("est-status").textContent="送信への同意にチェックを入れてください。";return}
  runEstimate(estFile);
};
$("est-sample").onclick=async()=>{
  if(!sel.before.length)setSel("before",["鼻フルコース"]);
  const label=$("estimate").parentElement;label.querySelector("img")?.remove();const img=new Image();img.alt="架空の見積書";img.src="sample-estimate.jpg";label.prepend(img);label.querySelector("span").hidden=true;
  runEstimate(await (await fetch("sample-estimate.jpg")).blob());
};
async function copyFrom(btnId,boxId,label){
  try{await navigator.clipboard.writeText($(boxId).value);$(btnId).textContent="✓ コピーしました";setTimeout(()=>{$(btnId).textContent=label},2400)}
  catch{$(boxId).select();$(btnId).textContent="選択しました。コピーしてください"}
}
$("est-copy").onclick=()=>copyFrom("est-copy","est-questions","質問をコピー");
$("prep").onclick=async()=>{
  const goal=$("goal").value.trim();if(!goal){$("prep-status").textContent="変えたいことを入力してください。";return}
  const btn=$("prep");btn.disabled=true;$("prep-status").textContent="作成しています。";$("prep-out").hidden=true;
  try{
    const r=await post("/api/prep",{procedure:sel.before.join("、")||"未定",goal,said:"",pressure:checked("pressure").map(i=>PRESSURE[i]),facts:groupsOf(sel.before).filter(g=>g.guide).slice(0,5).map(g=>("指針の記載："+g.guide).slice(0,200))});
    $("questions").replaceChildren(...r.questions.map(q=>el("li","",q)));
    $("options").replaceChildren(...r.options.map(o=>{const li=el("li");li.append(el("b","",o.option),el("span","",o.note));return li}));
    $("prep-out").hidden=false;$("prep-status").textContent="";
  }catch(e){$("prep-status").textContent=errorText(e)}finally{btn.disabled=false}
};

// 3 経過：施術日がない・未来の日付のときは「一般的な経過」とし、個人の時期の言葉を使わない
$("surgery").max=today;$("prev-date").max=today;
$("surgery").value=store.get("surgery","");$("prev-date").value=daysAgo(1);
const isFuture=()=>Boolean($("surgery").value)&&diff($("surgery").value,today)<0;
const dayNow=()=>!$("surgery").value||isFuture()?null:diff($("surgery").value,today);
const rangeLabel=(from,to)=>to>=9999?`${from}日〜`:from===0?`〜${to}日`:`${from}〜${to}日`;
function flowRows(g){let from=0;return g.flow.map(([to,t])=>{const r=[rangeLabel(from===0?0:from+1,to),t,from,to];from=to;return r})}
function stageCards(g,d){
  const box=el("div","stages");if(!g.flow.length)return box;
  const rows=flowRows(g);
  if(d===null){for(const [lab,t] of rows){const c=el("div","stage");c.append(el("b","",lab),el("span","",t.split("。")[0]+"。"));box.append(c)}return box}
  let i=rows.findIndex(r=>d<=r[3]);
  if(i<0){const c=el("div","stage on");c.append(el("b","","今"),el("span","","この時期の目安は、確認した出典にありません。"));box.append(c);return box}
  rows.slice(i,i+3).forEach(([lab,t],n)=>{const c=el("div","stage"+(n===0?" on":""));c.append(el("b","",n===0?"今":lab),el("span","",t.split("。")[0]+"。"));box.append(c)});
  return box;
}
const dayAngle=(d)=>-130+Math.log1p(Math.min(d,365))/Math.log1p(365)*260;
function drawDial(d){
  const c=150,pt=(deg,r)=>{const a=(deg-90)*Math.PI/180;return[c+r*Math.cos(a),c+r*Math.sin(a)]},arc=(from,to,r)=>{const [x1,y1]=pt(from,r),[x2,y2]=pt(to,r);return`M${x1} ${y1}A${r} ${r} 0 ${to-from>180?1:0} 1 ${x2} ${y2}`};
  let t="";for(let i=0;i<=78;i++){const deg=-130+i/78*260,[x1,y1]=pt(deg,i%13?126:121),[x2,y2]=pt(deg,131);t+=`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="tk${i%13?"":" maj"}"/>`}
  const marks=[[0,"当日"],[7,"1週"],[30,"1か月"],[90,"3か月"],[365,"1年"]].map(([v,l])=>{const [x,y]=pt(dayAngle(v),108);return`<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle">${l}</text>`}).join("");
  const ang=dayAngle(d),[nx,ny]=pt(ang,131),[sx,sy]=pt(ang,92);
  $("dial").innerHTML=`<svg viewBox="0 0 300 250">${t}${d>0?`<path d="${arc(-130,ang,139)}" fill="none" stroke="#24372F" stroke-width="2.5" stroke-linecap="round"/>`:""}${marks}<line x1="${sx}" y1="${sy}" x2="${nx}" y2="${ny}" stroke="#592833" stroke-width="2" stroke-linecap="round"/><circle cx="${nx}" cy="${ny}" r="3.6" fill="#FAF8F2" stroke="#592833" stroke-width="1.5"/></svg>`;
}
const modelIndex=(d)=>{let k=0;if(d!==null)MODEL.forEach(([,,v],i)=>{if(d>=v)k=i});return k};
function modelViewer(){
  const box=el("details","model");box.append(el("summary","","AI生成の見本写真で、流れを見る"));
  const fig=el("figure"),img=el("img");img.alt="AI生成の架空の人物による、鼻の手術のモデル経過";img.loading="lazy";
  const cap=el("figcaption");fig.append(img,cap);
  const seg=el("div","seg seg7");
  const show=(k)=>{const [f,l]=MODEL[k];img.src=`model/${f}-front.jpg`;cap.textContent=`${l}（AI生成のモデル経過。架空の人物で、実在の症例ではありません）`;[...seg.children].forEach((b,i)=>b.setAttribute("aria-pressed",String(i===k)))};
  MODEL.forEach(([,l],k)=>{const b=el("button","",l);b.type="button";b.onclick=()=>show(k);seg.append(b)});
  box.append(seg,fig,el("p","fine","流れを思い浮かべるための見本です。あなたの経過の基準ではありません。"));
  box.addEventListener("toggle",()=>{if(box.open&&!img.getAttribute("src"))show(modelIndex(dayNow()))});
  return box;
}
function drawCurve(day){
  const L=36,R=464,T=14,B=120,lx=v=>L+(Math.log(v)-Math.log(3))/(Math.log(365)-Math.log(3))*(R-L),y=v=>B-v/100*(B-T);
  const line=BANDS.std.map((v,i)=>`${lx(BANDS.days[i])},${y(v)}`).join(" ");
  const measured=[[30,33.3],[180,5],[365,2.5]].map(([d,v])=>`<circle cx="${lx(d)}" cy="${y(v)}" r="5" class="pt-m"/>`).join("");
  const labels=[[3,"3日"],[14,"2週"],[30,"1か月"],[90,"3か月"],[365,"1年"]].map(([d,t])=>`<text x="${lx(d)}" y="136" text-anchor="middle">${t}</text>`).join("");
  const mx=day===null?0:lx(Math.max(3,Math.min(365,day)));
  const m=day===null?"":`<line x1="${mx}" x2="${mx}" y1="${T}" y2="${B}" stroke="#592833" stroke-width="2"/><text x="${Math.min(mx+4,430)}" y="${T+8}" class="today">今日</text>`;
  $("curve").innerHTML=`<svg viewBox="0 0 490 142" role="img" aria-label="鼻の腫れが引いていく一般的な流れ。研究で測った値は1か月で約3分の1、6か月で5%、1年で2.5%が残る。${day===null?"":"縦線は施術からの日数。"}"><polyline points="${line}" fill="none" stroke="#777D61" stroke-width="2" stroke-dasharray="5 4"/>${measured}<text x="0" y="${y(100)+4}">100%</text><text x="8" y="${y(0)+2}">0%</text>${labels}${m}</svg>`;
}
function renderGuide(d){
  const box=$("guide");box.replaceChildren();$("guide-box").hidden=!sel.after.length;
  $("guide-title").textContent=d===null?"一般的な経過":"今の時期の目安";
  for(const g of afterGroups()){
    const c=el("div","guide-item");c.append(el("h3","",g.label));
    if(g.flow.length)c.append(stageCards(g,d));else c.append(el("p","","時期の目安は、確認した出典にありません。"));
    if(g===GROUPS.nose){
      const det=el("details","dist"),cv=el("div");cv.id="curve";
      det.append(el("summary","","腫れが引いていく流れを見る"),el("p","fine","縦は、手術直後を100%としたときに残っている腫れの割合です。●は研究で測った値（Pavri 2016：鼻の手術を受けた40人の3D計測。1か月・6か月・1年）。点線は、大学病院の説明をもとに点の間を補った線で、測った値ではありません。人による違いの幅は、裏付けとなるデータがないため示していません。"),cv);
      c.append(det,modelViewer());
    }
    c.append(srcLine(g));box.append(c);
  }
  if($("curve"))drawCurve(d);
}

// 記録
const realRows=()=>store.get("records",[]).filter(r=>typeof r==="object"&&r);
const lastRec=()=>realRows().filter(r=>r.date!==today).at(-1)||null;
function upsertRecord(){const recs=realRows().filter(r=>r.date!==today);recs.push({date:today,day:dayNow(),...levels});recs.sort((a,b)=>a.date<b.date?-1:1);store.set("records",recs.slice(-60));return recs.length}
function meter(v){const s=el("span","m");if(v==null){s.textContent="−";return s}s.append(el("b","",String(v)));const bar=el("i");bar.style.setProperty("--v",v);s.append(bar);return s}
function recRows(rows,title){
  const box=$("records");box.replaceChildren();
  if(title)box.append(el("h3","",title));
  if(!rows.length){box.append(el("p","fine","まだ記録はありません。"));return}
  const tb=el("div","rec"),hd=el("div","rec-row rec-head");hd.append(el("span","","日付"),...LEVELS.map(([,l])=>el("span","",l)));tb.append(hd);
  for(const r of [...rows].reverse()){const row=el("div","rec-row"),d=el("span","rec-d");d.append(el("b","",r.date?md(r.date):"−"),el("small","",r.day==null?"":r.day===0?"当日":`${r.day}日目`));row.append(d,...LEVELS.map(([k])=>meter(r[k])));tb.append(row)}
  box.append(tb);
}
let showingSample=false;
function renderRecDiff(){
  const rows=realRows(),box=$("rec-diff");
  if(showingSample||rows.length<2){box.hidden=true;return}
  const [a,b]=rows.slice(-2),parts=LEVELS.filter(([k])=>a[k]!=null||b[k]!=null).map(([k,l])=>`${l} ${a[k]??"−"}→${b[k]??"−"}`);
  box.hidden=!parts.length;box.textContent=`前回（${md(a.date)}）と今回（${md(b.date)}）：${parts.join("、")}`;
}
function renderWeek(){
  const dates=new Set(realRows().map(r=>r.date)),box=$("week-dots");box.replaceChildren();let n=0;
  for(let k=6;k>=0;k--){const iso=daysAgo(k),w="日月火水木金土"[new Date(iso+"T00:00:00").getDay()],i=el("i","",w);if(dates.has(iso)){i.className="on";n++}if(k===0)i.classList.add("now");box.append(i)}
  $("week-count").textContent=n?`7日のうち${n}日、記録できました`:"まだ今週の記録はありません";
}
$("sample-rec").onclick=()=>{showingSample=!showingSample;$("sample-rec").textContent=showingSample?"自分の記録に戻す":"見本の7日を見る";if(showingSample)recRows(SAMPLE.map(([day,pain,swell,bruise])=>({day,pain,swell,bruise})),"見本（架空の記録）");else recRows(realRows());renderRecDiff()};
$("clear-rec").onclick=()=>{if(!confirm("この端末の記録と経過写真をすべて消します。元に戻せません。"))return;store.del("records");idb.clear().then(()=>loadPhotos(false));showingSample=false;$("sample-rec").textContent="見本の7日を見る";refresh()};

// 今日の感じ：前回の値を横に見せる。自動では選ばない。
const levels={};
function renderLevels(){
  const box=$("levels"),prev=lastRec();box.replaceChildren();
  box.append(el("p","q","今日の感じ（0がなし、5が強い）"));
  for(const [k,label] of LEVELS){
    const f=el("fieldset","level"),lg=el("legend");lg.append(el("span","",label));
    const pv=prev&&prev[k]!=null?prev[k]:null;if(pv!=null)lg.append(el("span","prev",`前回 ${pv}（${md(prev.date)}）`));f.append(lg);
    const row=el("div","level-row");
    for(let v=0;v<=5;v++){const b=el("button","",v===0?"なし":String(v));b.type="button";b.setAttribute("aria-pressed",String(levels[k]===v));b.setAttribute("aria-label",`${label} ${v}${pv===v?"（前回の値）":""}`);if(pv===v)b.classList.add("was");
      b.onclick=()=>{if(levels[k]===v)delete levels[k];else levels[k]=v;[...row.children].forEach((c,i)=>c.setAttribute("aria-pressed",String(levels[k]===i)))};row.append(b)}
    f.append(row);box.append(f);
  }
}

// 受診を急ぐサイン：毎回、未回答から。答えるまで記録もメモも作らない。
let safety=null;
function updateSafety(){
  for(const b of $("safety-seg").children)b.setAttribute("aria-pressed",String(b.dataset.v===safety));
  $("flags").hidden=safety!=="some";$("flag-list").hidden=safety==="some";
  const f=checked("flag"),box=$("urgent");box.hidden=safety!=="some";
  const inject=afterGroups().some(g=>g===GROUPS.hyal||g===GROUPS.fat||g===GROUPS.inject);
  box.textContent=f.some(i=>FLAGS[i][1])||(inject&&f.includes(7))?"今すぐ119番に連絡してください。":"記録やメモを待たず、今すぐクリニックへ電話してください。時間外なら緊急連絡先へ。つながらないときは、救急安心センター #7119（地域による）へ。";
}
for(const b of $("safety-seg").children)b.onclick=()=>{safety=b.dataset.v;if(safety==="none")for(const i of document.querySelectorAll("input[name=flag]"))i.checked=false;updateSafety()};
$("flags").onchange=updateSafety;

// 写真：前回の自分か、AI生成の見本と、この端末の中だけで見比べる。自分の写真は端末の中（IndexedDB）に日付ごとに残す。
const idb=(()=>{let p=null;const open=()=>p??=new Promise((ok,ng)=>{try{const r=indexedDB.open("dc-photos",1);r.onupgradeneeded=()=>r.result.createObjectStore("photos",{keyPath:"date"});r.onsuccess=()=>ok(r.result);r.onerror=()=>ng(r.error)}catch(e){ng(e)}});
  const run=async(mode,fn)=>{const db=await open();return new Promise((ok,ng)=>{const t=db.transaction("photos",mode),req=fn(t.objectStore("photos"));t.oncomplete=()=>ok(req?.result);t.onerror=()=>ng(t.error)})};
  return{put:r=>run("readwrite",s=>s.put(r)).catch(()=>null),all:()=>run("readonly",s=>s.getAll()).catch(()=>[]),clear:()=>run("readwrite",s=>s.clear()).catch(()=>null)}})();
const photos={};let cmpTarget="prev",modelView="front",modelStage=null;
const modelSrc=(k,v)=>`model/${MODEL[k][0]}-${v}.jpg`;
function setPhoto(id,blob,src){
  const label=$(id).parentElement;label.querySelector("img")?.remove();
  photos[id]=blob||null;label.querySelector("span").hidden=!!blob;
  if(blob){const img=new Image();img.alt="";img.src=src||URL.createObjectURL(blob);label.prepend(img)}
  updateCmp();
}
for(const id of["yesterday","today"])$(id).onchange=e=>{photos.sample=false;if(id==="yesterday")$("prev-info").hidden=true;setPhoto(id,e.target.files[0])};
$("photo-sample").onclick=async()=>{
  const [a,b]=await Promise.all([modelSrc(1,"front"),modelSrc(2,"front")].map(async u=>(await fetch(u)).blob()));
  photos.sample=true;setTarget("prev");setPhoto("yesterday",a,modelSrc(1,"front"));setPhoto("today",b,modelSrc(2,"front"));$("prev-date").value=daysAgo(4);
  $("prev-info").hidden=true;
};
function setTarget(t){cmpTarget=t;for(const c of $("cmp-target").children)c.setAttribute("aria-pressed",String(c.dataset.t===t));$("prev-wrap").hidden=t!=="prev";$("model-opts").hidden=t!=="model";$("prev-info").classList.toggle("off",t==="model");updateCmp()}
for(const b of $("cmp-target").children)b.onclick=()=>setTarget(b.dataset.t);
$("model-stage").replaceChildren(...MODEL.map(([,l],k)=>{const o=el("option","",l);o.value=k;return o}));
$("model-stage").onchange=()=>{modelStage=Number($("model-stage").value);updateCmp()};
for(const b of $("model-view").children)b.onclick=()=>{modelView=b.dataset.v;for(const c of $("model-view").children)c.setAttribute("aria-pressed",String(c===b));updateCmp()};
function updateCmp(){
  const a=$("cmp-a"),b=$("cmp-b"),k=modelStage??modelIndex(dayNow());$("model-stage").value=k;
  const ready=photos.today&&(cmpTarget==="model"||photos.yesterday);$("cmp").hidden=!ready;if(!ready)return;
  if(b.dataset.u)URL.revokeObjectURL(b.dataset.u);b.dataset.u=URL.createObjectURL(photos.today);
  b.onload=()=>{$("cmp-stage").style.aspectRatio=`${b.naturalWidth}/${b.naturalHeight}`};b.src=b.dataset.u;
  if(cmpTarget==="model"){const l=MODEL[k][1];a.src=modelSrc(k,modelView);$("tag-a").textContent=`AI見本 ${l}`;$("cmp-note").textContent=`見本はAI生成の架空の人物（鼻の手術、${l}、${modelView==="front"?"正面":"横顔"}）です。標準や正解ではありません。違いの判断は、あなたと先生が行います。`}
  else{if(a.dataset.u)URL.revokeObjectURL(a.dataset.u);a.dataset.u=URL.createObjectURL(photos.yesterday);a.src=a.dataset.u;$("tag-a").textContent=photos.sample?"前回":`前回 ${md($("prev-date").value)}`;$("cmp-note").textContent=photos.sample?"AI生成のモデル経過（3日後と1週間後）の見本です。架空の人物で、実在の症例ではありません。":"変化の判断は、あなたと先生が行います。"}
}
let cmpMode="slide";
function setCmp(){const v=$("cmp-range").value,st=$("cmp-stage");st.classList.toggle("blend",cmpMode==="blend");if(cmpMode==="blend")st.style.setProperty("--o",v);else st.style.setProperty("--p",v+"%")}
$("cmp-range").oninput=setCmp;
for(const b of $("cmp-seg").children)b.onclick=()=>{cmpMode=b.dataset.m;for(const c of $("cmp-seg").children)c.setAttribute("aria-pressed",String(c===b));setCmp()};
const pairReady=()=>cmpTarget==="prev"&&photos.yesterday&&photos.today;
// 保存した経過写真：前回の写真を自動で入れ、並びを出す
let savedPhotos=[];
async function loadPhotos(first){
  savedPhotos=(await idb.all()).sort((x,y)=>x.date<y.date?-1:1);
  const box=$("photo-timeline");box.replaceChildren();$("tl-box").hidden=!savedPhotos.length;
  for(const r of [...savedPhotos].reverse()){
    const b=el("button","tl-item");b.type="button";const img=new Image();img.alt=`${md(r.date)}の写真`;img.src=URL.createObjectURL(r.blob);
    b.append(img,el("span","",md(r.date)+(r.day!=null?` ・ ${r.day?r.day+"日目":"当日"}`:"")));
    b.onclick=()=>{if(r.date===today)return;usePrev(r);setTarget("prev");$("photo-box").scrollIntoView({behavior:"smooth",block:"start"})};box.append(b);
  }
  if(first){
    const prev=savedPhotos.filter(r=>r.date<today).at(-1),own=savedPhotos.find(r=>r.date===today);
    if(prev)usePrev(prev);
    if(own&&!photos.today){photos.sample=false;setPhoto("today",own.blob)}
  }
}
function usePrev(r){photos.sample=false;$("prev-date").value=r.date;setPhoto("yesterday",r.blob);$("prev-info").hidden=false;$("prev-info").textContent=`前回の写真に、${md(r.date)}${r.day!=null?`（${r.day?r.day+"日目":"当日"}）`:""}に残した写真を入れました。`}
$("clinic").value=store.get("clinic","");$("clinic").onchange=()=>store.set("clinic",$("clinic").value.trim());

// 記録して短いメモを作る（送信しない）
function checkToday(statusId){
  const say=t=>{$(statusId).textContent=t;return false};
  if(!sel.after.length)return say("受けた施術を選んでください。");
  if(dayNow()===null)return say(isFuture()?"施術日が未来の日付です。受けた日を入れてください。":"施術日を入れてください。");
  if(!safety)return say("はじめに「受診を急ぐサインはありますか」に答えてください。");
  if(!Object.keys(levels).length&&!$("note").value.trim())return say("今日の感じを選んでください。");
  return true;
}
function memoText(){
  const d=dayNow(),lv=LEVELS.filter(([k])=>levels[k]!=null).map(([k,l])=>`${l} ${levels[k]===0?"なし":levels[k]+"/5"}`).join("　"),fl=checked("flag").map(i=>FLAGS[i][0]),note=$("note").value.trim();
  const clinic=$("clinic").value.trim(),obs=$("obs").value.trim();
  const L=clinic?[`${clinic} ご担当者様`,""]:[];L.push(`【${sel.after.join("・")}／術後${d?d+"日目":"当日"}】`);
  if(lv)L.push("・今日の感じ："+lv);
  L.push(safety==="none"?"・受診を急ぐサイン：一覧の項目には当てはまらない（本人の確認）":fl.length?"・気になる症状："+fl.join("、"):"・受診を急ぐサイン：あるかもしれない（本人が判断できない）");
  if(note)L.push("・気になっていること："+note);
  if(obs&&!$("cmp").hidden)L.push("・写真を見て気づいたこと："+obs);
  if(pairReady()&&!photos.sample)L.push(`・写真：${md($("prev-date").value)}と${md(today)}の2枚を添付します`);
  L.push(safety==="some"?"至急、ご指示をお願いします。":"このまま経過を見てよいか、ご確認をお願いします。");
  return L.join("\n");
}
$("save-rec").onclick=()=>{
  if(!checkToday("save-status"))return;$("save-status").textContent="";
  const hasLv=Object.keys(levels).length>0,n=hasLv?upsertRecord():realRows().length;
  if(photos.today&&!photos.sample)idb.put({date:today,day:dayNow(),blob:photos.today}).then(r=>{if(r==null){$("saved").textContent=$("saved").textContent.replace("。写真もこの端末に残しました","");$("photo-fail").hidden=false}else{$("photo-fail").hidden=true;loadPhotos(false)}});
  $("memo").value=memoText();$("long-out").hidden=true;$("long-empty").hidden=false;
  $("saved").textContent=hasLv?`今日の記録を残しました（${n}回目）${photos.today&&!photos.sample?"。写真もこの端末に残しました":""}`:"メモを作りました（今日の感じが空のため、記録には残していません）";
  $("report-meta").textContent=`${sel.after.join("、")} ・ 施術後${dayNow()}日目 ・ ${md(today)}`;
  $("report").hidden=false;refresh();$("report").scrollIntoView({behavior:"smooth",block:"start"});
};
$("copy-memo").onclick=()=>copyFrom("copy-memo","memo","メモをコピー");
$("copy-long").onclick=()=>copyFrom("copy-long","message","丁寧な文章をコピー");
const TREND={reduced:"軽減",same:"変化なし",increased:"増加",unclear:"不明"};
$("compare").onclick=async()=>{
  if(!checkToday("compare-status"))return;
  if(!$("consent").checked){$("compare-status").textContent="送信への同意にチェックを入れてください。";return}
  const btn=$("compare");btn.disabled=true;const stop=working("compare-status",["入力を確認しています","Geminiが内容を読んでいます","文章を整えています"]);
  try{
    const pair=pairReady(),[yesterday,todayImg]=pair?await Promise.all([toJpeg(photos.yesterday),toJpeg(photos.today)]):[undefined,undefined];
    const r=await post("/api/analyze",{procedures:sel.after,postOpDay:Math.min(730,dayNow()),levels:Object.fromEntries(Object.entries(levels).filter(([,v])=>v>0)),intervalDays:pair?Math.max(1,diff($("prev-date").value||daysAgo(1),today)):undefined,note:[LEVELS.filter(([k])=>levels[k]===0).map(([,l])=>l+"：なし").join("、"),$("note").value.trim(),$("obs").value.trim()&&!$("cmp").hidden?"写真を見て気づいたこと："+$("obs").value.trim():""].filter(Boolean).join("\n").slice(0,300),redFlags:checked("flag").map(i=>FLAGS[i][0]),yesterday,today:todayImg,consent:true});
    const blocked=r.comparability==="not_comparable";
    $("limit").textContent=blocked?`この2枚は比較できませんでした。${r.comparabilityNote} 同じ部位を同じ角度で撮り直してください。`:(r.comparabilityNote||"");
    $("limit").hidden=!$("limit").textContent;$("diff").hidden=blocked;
    $("summary").textContent=r.summary||"";$("changes").hidden=!(r.changes||[]).length;
    $("changes").replaceChildren(...(r.changes||[]).map(c=>{const li=el("li");li.append(el("b","",c.area),el("span","",`${c.change}（${TREND[c.trend]||"不明"}）`));return li}));
    $("message").value=blocked?"":r.consultationMessage;$("message").closest(".field").hidden=blocked;$("copy-long").hidden=blocked;
    if(!blocked&&Object.keys(levels).length)upsertRecord();
    $("long-out").hidden=false;stop();$("compare-status").textContent="";refresh();
  }catch(e){stop();$("compare-status").textContent=errorText(e)}finally{btn.disabled=false}
};

// 全体の更新
let editingSetup=null;
function refresh(){
  const d=dayNow(),has=sel.after.length>0&&d!==null;
  renderChips();renderPrice();renderKnow();renderGuide(d);renderLevels();updateSafety();
  // ホーム
  $("hero-day").hidden=!has;$("home-procs").hidden=!has;$("home-week").hidden=!has;
  const entries=[...document.querySelectorAll(".journey .entry")];
  entries.forEach((e,i)=>e.classList.toggle("primary",has?i===2:i===0));
  $("go-after-label").textContent=has?`${d?d+"日目":"当日"}の経過を記録する`:"経過を記録する";
  if(has){drawDial(d);$("home-day").textContent=d||"当";$("home-procs").textContent=sel.after.join("、")}
  renderWeek();
  // 経過の設定
  $("daytext").textContent=!$("surgery").value?"施術日を入れると、施術からの日数に合わせた目安を出します。":isFuture()?"未来の日付です。施術を受けた日を入れてください。":d?`施術後${d}日目`:"施術当日";
  $("daytext").classList.toggle("warn",isFuture());
  if(editingSetup===null)editingSetup=!has;
  $("setup-done").hidden=!has||!editingSetup;$("setup-view").hidden=!has||editingSetup;$("setup-form").hidden=has&&!editingSetup;
  if(has){$("setup-procs").textContent=sel.after.join("、");$("setup-day").textContent=`施術日 ${md($("surgery").value)} ・ ${d?d+"日目":"当日"}`}
  const cb=$("copy-before");cb.hidden=!(sel.before.length&&!sel.after.length);if(!cb.hidden)cb.textContent=`「${sel.before.join("・")}」を受けた`;
  const noPhoto=sel.after.some(n=>byName(n).noPhoto);
  $("photo-box").hidden=noPhoto;$("no-photo").hidden=!noPhoto;if(noPhoto)photos.yesterday=photos.today=null;
  if(!showingSample)recRows(realRows());renderRecDiff();
}
$("copy-before").onclick=()=>setSel("after",[...sel.before]);
$("surgery").onchange=()=>{store.set("surgery",isFuture()?"":$("surgery").value);refresh()};
$("setup-edit").onclick=()=>{editingSetup=true;refresh()};
$("setup-done").onclick=()=>{editingSetup=false;refresh();$("today-box").scrollIntoView({behavior:"smooth",block:"start"})};

// 書き出しと読み込み：記録と写真を1つのファイルにして持ち出せる
const b64=blob=>new Promise(ok=>{const r=new FileReader();r.onload=()=>ok(r.result);r.readAsDataURL(blob)});
$("export").onclick=async()=>{
  const ph=await idb.all(),data={app:"downtime-compass",version:1,exported:today,procsAfter:sel.after,surgery:$("surgery").value,clinic:$("clinic").value,records:realRows(),photos:await Promise.all(ph.map(async r=>({date:r.date,day:r.day,image:await b64(r.blob)})))};
  const a=el("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data)],{type:"application/json"}));a.download=`downtime-compass-${today}.json`;document.body.append(a);a.click();a.remove();
  $("io-status").textContent=`記録${data.records.length}件と写真${data.photos.length}枚を書き出しました。ファイルは、ほかの人に送らず大切に保管してください。`;
};
$("import").onchange=async e=>{
  const f=e.target.files[0];if(!f)return;
  try{
    const d=JSON.parse(await f.text());if(d.app!=="downtime-compass")throw 0;
    const merged=[...realRows().filter(r=>!d.records.some(x=>x.date===r.date)),...d.records].sort((a,b)=>a.date<b.date?-1:1);
    store.set("records",merged.slice(-60));if(d.procsAfter?.length&&!sel.after.length)setSel("after",d.procsAfter.filter(byName));
    if(d.surgery&&!$("surgery").value){$("surgery").value=d.surgery;store.set("surgery",d.surgery)}
    if(d.clinic&&!$("clinic").value){$("clinic").value=d.clinic;store.set("clinic",d.clinic)}
    let n=0;for(const p of d.photos||[]){const blob=await (await fetch(p.image)).blob();if(await idb.put({date:p.date,day:p.day,blob})!=null)n++}
    $("io-status").textContent=`記録${d.records.length}件と写真${n}枚を読み込みました。`;refresh();loadPhotos(true);
  }catch{$("io-status").textContent="このファイルは読み込めませんでした。このアプリで書き出したファイルを選んでください。"}
  e.target.value="";
};
try{navigator.storage?.persist?.()}catch{}

refresh();
loadPhotos(true);
